using UnityEngine;

public class sawMove : MonoBehaviour
{
    public float speed = 2f;      // vitesse du mouvement
    public float decalage = 0.029f; // décalage sur l'axe X
    public Transform planche1;
    public Transform planche2;

    [Range(1f, 5f)]
    public float easePower = 3f;  // plus grand = ralentissement plus marqué

    void Update()
    {
        // PingPong de 0 à 1 pour aller-retour
        float progress = Mathf.PingPong(Time.time * speed, 1);

        // EaseInOut aux deux extrémités (A et B)
        float eased = EaseInOut(progress, easePower);

        // Points avec décalage X
        Vector3 pointA = planche1.position + new Vector3(decalage, 0f, 0f);
        Vector3 pointB = planche2.position + new Vector3(decalage, 0f, 0f);

        // Déplacement
        transform.position = Vector3.Lerp(pointA, pointB, eased);
    }

    // Fonction EaseInOut personnalisée
    float EaseInOut(float t, float power)
    {
        // t entre 0 et 1
        return t < 0.5f
            ? 0.5f * Mathf.Pow(t * 2f, power)           // première moitié : accélération
            : 1f - 0.5f * Mathf.Pow(2f * (1f - t), power); // deuxième moitié : décélération
    }
}
