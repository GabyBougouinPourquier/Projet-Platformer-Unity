using UnityEngine;
using UnityEngine.Rendering.Universal;
public class flag : MonoBehaviour
{
    public Animator animator;
    public bool isActivated = false;

    public Player playerScript;
    Light2D lightComponent;

    void Start()
    {
        lightComponent = GetComponentInChildren<Light2D>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player") && isActivated == false)
        { 
            isActivated = true;
            animator.SetBool("Activate", true);
            playerScript.NewCheckpoint(transform.position);
    
            lightComponent.intensity = 0.5f;

        }
    }
    public void Desactivate()
    {
        animator.SetBool("Activate", false);
        isActivated = false;
        lightComponent.intensity = 0f;
    }
}
