using UnityEngine;

public class gemForBig : MonoBehaviour
{
    public Player playerScirpt;
    public void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.CompareTag("Player")) 
        {
            playerScirpt.SizeChagement("up");
        }
    }
}
