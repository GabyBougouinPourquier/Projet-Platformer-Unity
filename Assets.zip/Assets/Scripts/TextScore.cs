using UnityEngine;
using TMPro;

public class TextScore : MonoBehaviour
{
    

    public int score = 0;

    public TMP_Text text;
    string originalText;

    void Start()
    {
        originalText = text.text;
        UpdateScore();
    }

    public void ChangeScore(int scoreChanger)
    {
        score += scoreChanger;
        UpdateScore();
    }

    void UpdateScore()
    {
        text.text = ""+score;
    }


}