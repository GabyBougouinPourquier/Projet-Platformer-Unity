using UnityEngine;

public class gemForLess : MonoBehaviour
{

    public Player playerScirpt;


    public void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.CompareTag("Player")) 
        {
            playerScirpt.SizeChagement("down");
        }
    }
}
