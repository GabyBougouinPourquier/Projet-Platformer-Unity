using UnityEngine;

public class DeathZone : MonoBehaviour
{
    public Player playerScript;
    private void OnTriggerEnter2D(Collider2D context)
    {
        if (context.CompareTag("Player"))
        {
            playerScript.Death();
        }
    }
}
