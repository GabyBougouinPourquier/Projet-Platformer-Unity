using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class CircleUI : MonoBehaviour
{
    public Image redCircleImage;
    public Hearts heartsScript;
    public bool isWait = false;
    void Start()
    {
        redCircleImage.fillAmount = 0f;
    }
    public void ResetAll()
    {
        isWait = false;
        redCircleImage.fillAmount = 0f;
    }
    public void UpdateCircle(float fillAmount)
    {
        if (fillAmount >= 0f && fillAmount <= 1f )
        {
            if (redCircleImage.fillAmount + fillAmount != 1f)
            {
                redCircleImage.fillAmount += fillAmount;
            }

            if (redCircleImage.fillAmount >= 1f)
            {
                if (heartsScript.VerifFull())
                {
                    isWait = true;
                }
                else
                {
                    heartsScript.ChangeHeal(1);
                    redCircleImage.fillAmount = 0f;
                }
                
            }
        }
        else
        {
            Debug.Log("fillAmount doit être entre 0 et 1 !");
        }
    }
}
