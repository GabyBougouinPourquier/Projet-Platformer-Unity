using UnityEngine;

public class apple : MonoBehaviour
{
    public float ratio = 3f;
    float circlePoint = 0.25f;
    public TextScore textScore;
    public CircleUI circleUI;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            // ajouter les points
            textScore.ChangeScore(2);
            circlePoint = 1/ratio;
            circleUI.UpdateCircle(circlePoint);
            // Le faire disparaitre
            Destroy(gameObject);
            // les particules ( optionnel ) 
            
        }
    }
}
