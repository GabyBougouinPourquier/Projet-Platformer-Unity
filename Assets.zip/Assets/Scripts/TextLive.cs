using UnityEngine;
using TMPro;

public class TextLive : MonoBehaviour
{
    public Player playerScript;

    static int life = 3;

    public TMP_Text text;
    string originalText;

    int newHeal;

    void Start()
    {
        originalText = text.text;      // sauvegarde du texte de base
        text.text = originalText + life;
    }

    public void ChangeHeal(int heal)
    {
        newHeal = heal;
        Debug.Log("HEAL: "+newHeal);
        if (newHeal < 0)
        {
            newHeal = -1;
            Debug.Log("newHeal < 0");
        }

        life += newHeal;
        Debug.Log("LIFE: "+life);
        if (life == 0)
        {
            playerScript.ReallyDeath();
        }
        text.text = originalText + life;
    }


}
