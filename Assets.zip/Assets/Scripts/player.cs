
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using Unity.VisualScripting;

public class Player : MonoBehaviour
{
    [Header("Liste des drapeaux (checkpoints)")]
    public List<GameObject> flags = new List<GameObject>();
    int indexInListeOfFlags = 0;
    
    [Header("Scripts Referance")]
    public flag flagScript;
    public Hearts heartScript;
    [Header("References")]
    public Rigidbody2D rb;
    public Transform groundCheck;
    public LayerMask groundLayer;

    [Header("Movement")]
    public float speed = 6f;
    public Animator animator;

    [Header("Jump")]
    public float jumpForce = 6f;        // impulsion initiale
    public float jumpHoldForce = 20f;   // force maintenue
    public float maxJumpTime = 0.2f;    // durée max du maintien

    [Header("Ground Check Settings")]
    public Vector2 groundCheckSize = new Vector2(0.25f, 0.05f); // taille du détecteur
    [Header("Position de départ/CheckPoint")]
    public Vector3 checkpoint;
    private Vector3 originalCheckpoint;
    // = new Vector3(-0.723999977f,-2.72368526f,0);
    
    float horizontal;
    bool isJumping;
    float jumpTimeCounter;

    private bool isInvincible = false;
    public float invincibleTime = 1f;
    public bool ePressed = false;
    float speedTest = 0f;
    SpriteRenderer sr;

    void Start()
    {
        originalCheckpoint = checkpoint;
        sr = GetComponent<SpriteRenderer>();
        checkpoint = new Vector3(-0.723999977f,-2.72368526f,0);
    }

    void FixedUpdate()
    {


        animator.SetFloat("speedX", speedTest);


        animator.SetFloat("speedY", rb.linearVelocity.y);
        // Déplacement horizontal
        rb.linearVelocity = new Vector2(horizontal * speed, rb.linearVelocity.y);

        // Maintien du saut (saut fluide)
        if (isJumping && jumpTimeCounter > 0f)
        {
            rb.AddForce(Vector2.up * jumpHoldForce);
            jumpTimeCounter -= Time.fixedDeltaTime;
        }
        else
        {
            isJumping = false;
        }
    }

    public bool SizeChagement(string size)
    {
        if (!ePressed)return false;
        Vector3 small  = new Vector3(0.5f, 0.5f, 1f);
        Vector3 normal = new Vector3(1f, 1f, 1f);
        Vector3 big    = new Vector3(1.5f, 1.5f, 1f);

        if (size == "up")
        {
            if (transform.localScale.x < 1f)
            {
                transform.localScale = normal;
                return true;
            }
            else if (transform.localScale.x < 1.5f)
            {
                transform.localScale = big;
                return true;
            }
        }
        else if (size == "down")
        {
            if (transform.localScale.x > 1f)
            {
                transform.localScale = normal;
                return true;
            }
            else if (transform.localScale.x > 0.5f)
            {
                transform.localScale = small;
                return true;
            }
        }

        return false;
    }


    public void ReallyDeath()
    {
        checkpoint = originalCheckpoint;
        transform.position = originalCheckpoint;
        heartScript.ChangeHeal(3);
        flagScript.Desactivate();

    }
    public void Death()
    {
        if (isInvincible) return;

        isInvincible = true;

        transform.position = checkpoint;
        heartScript.ChangeHeal(-1);

        Invoke(nameof(ResetInvincibility), invincibleTime);
    }

    void ResetInvincibility()
    {
        isInvincible = false;
    }

    public void NewCheckpoint(Vector3 newPos)
    {
        checkpoint = newPos;
    }

    
    // INPUT MOVE
    public void Move(InputAction.CallbackContext context)
    {
        horizontal = context.ReadValue<Vector2>().x;
        speedTest = Mathf.Abs(horizontal);
        
        if (horizontal != 0)
            sr.flipX = horizontal < 0;
    }

    // INPUT JUMP
    public void Jump(InputAction.CallbackContext context)
    {
        // Début du saut
        if (context.started && IsGrounded())
        {
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
            isJumping = true;
            jumpTimeCounter = maxJumpTime;
        }

        // Relâchement du bouton = saut plus court
        if (context.canceled && rb.linearVelocity.y > 0)
        {
            rb.linearVelocity = new Vector2(
                rb.linearVelocity.x,
                rb.linearVelocity.y * 0.5f
            );
            isJumping = false;
        }
    }

    public void Interaction(InputAction.CallbackContext context)
    {
        if (context.performed) ePressed = true;

        if (context.canceled) ePressed = false;
    } 
    bool IsGrounded()
    {
        return Physics2D.OverlapCapsule(
            groundCheck.position,
            groundCheckSize,
            CapsuleDirection2D.Vertical,
            0,
            groundLayer
        );
    }


    void OnDrawGizmos()
    {
        if (groundCheck == null) return;

        Gizmos.color = Color.red;

        Vector2 pos = groundCheck.position;
        float width = groundCheckSize.x;
        float height = groundCheckSize.y;

        // Partie rectangle centrale
        Gizmos.DrawWireCube(pos, new Vector3(width, height, 0));

        // Deux cercles aux extrémités (pour simuler la capsule)
        float radius = height / 2f;

        Vector2 left = pos + Vector2.left * (width / 2f - radius);
        Vector2 right = pos + Vector2.right * (width / 2f - radius);

        Gizmos.DrawWireSphere(left, radius);
        Gizmos.DrawWireSphere(right, radius);
    }

}
