using UnityEngine;
using TMPro;
using UnityEngine.UI;
using Unity.VisualScripting;

public class Hearts : MonoBehaviour
{
    public Player playerScript;
    public CircleUI circleUI;
    public Image[] allHearts;
    int newHeal;

    int hearts = 3;
    public int maxHearts = 3;
    void Start()
    {
        for (int i = 0; i < allHearts.Length; i += 1)
        {
            allHearts[i].enabled = true;
        }
    }
    public void ChangeHeal(int heal)
    {
        newHeal = heal;
        
        if (hearts + newHeal <= maxHearts)
        {
            hearts += newHeal;
            if (newHeal < 0 && circleUI.isWait == true)
            {
                circleUI.ResetAll();
            }
            else
            {
                UpdateHeart();
                if (hearts == 0)
                {
                    playerScript.ReallyDeath();
                }
            }

        }

    }
    public bool VerifFull()
    {
        return hearts == maxHearts;
    }

    public void UpdateHeart()
    {
        for (int i = 0; i < allHearts.Length; i ++)
        {
            allHearts[i].enabled = i < hearts;
        }
    }

}
