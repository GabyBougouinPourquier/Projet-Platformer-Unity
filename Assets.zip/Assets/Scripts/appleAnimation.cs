using UnityEngine;

public class appleAnimation : MonoBehaviour
{
    public int index = 0;
    int nbFrame = 0;
    void Start()
    {
        
    }


    void Update()
    {
        nbFrame ++;
        
        if (index == 5 | index == 6 | index == 7)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y + 0.001f, 0);
        }
        else if (index == 8 | index == 9 | index == 10)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y + -0.001f, 0);
        }
        
        if (nbFrame == 100)
        {
            nbFrame = 0;
            index ++;
            if (index == 16)
            {
                index = 0;
            }
        }

        
    }
}
